
export default function Home() {
  return (
    <div className="main bg-black text-amber-50 h-screen">
      <h1>lsdflaksf</h1>
    
    </div>
  )
}